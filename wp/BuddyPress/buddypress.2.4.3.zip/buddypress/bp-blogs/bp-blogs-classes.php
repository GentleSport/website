<?php
/**
 * BuddyPress Blogs Classes.
 *
 * @package BuddyPress
 * @subpackage BlogsClasses
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

require dirname( __FILE__ ) . '/classes/class-bp-blogs-blog.php';

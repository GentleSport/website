<?php
/**
 * Placeholder for bbPress plugin bridge.
 *
 * @package BuddyPress
 * @subpackage ForumsbbPress
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
